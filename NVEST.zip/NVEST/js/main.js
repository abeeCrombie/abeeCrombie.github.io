jQuery(function($) {'use strict';

	// Navigation Scroll
		(function($){
		    $.fn.scrollingTo = function( opts ) {
		        var defaults = {
		            animationTime : 1000,
		            easing : '',
		            callbackBeforeTransition : function(){},
		            callbackAfterTransition : function(){}
		        };

		        var config = $.extend( {}, defaults, opts );

		        $(this).click(function(e){
		            var eventVal = e;
		            e.preventDefault();

		            var $section = $(document).find( $(this).data('section') );
		            if ( $section.length < 1 ) {
		                return false;
		            };

		            if ( $('html, body').is(':animated') ) {
		                $('html, body').stop( true, true );
		            };

		            var scrollPos = $section.offset().top;

		            if ( $(window).scrollTop() == scrollPos ) {
		                return false;
		            };

		            config.callbackBeforeTransition(eventVal, $section);

		            $('html, body').animate({
		                'scrollTop' : (scrollPos+'px' )
		            }, config.animationTime, config.easing, function(){
		                config.callbackAfterTransition(eventVal, $section);
		            });
		        });
		    };
		}(jQuery));


	$('.main-menu ul li a,.smooth-scroll').scrollingTo();



	//Slider
	$(document).ready(function() {
		var time = 7; // time in seconds

	 	var $progressBar,
	      $bar, 
	      $elem, 
	      isPause, 
	      tick,
	      percentTime;
	 
	    //Init the carousel
	    $("#main-slider").find('.owl-carousel').owlCarousel({
	      slideSpeed : 500,
	      paginationSpeed : 500,
	      singleItem : true,
	      navigation : true,
			navigationText: [
			"<i class='fa fa-angle-left'></i>",
			"<i class='fa fa-angle-right'></i>"
			],
	      afterInit : progressBar,
	      afterMove : moved,
	      startDragging : pauseOnDragging,
	      //autoHeight : true,
	      transitionStyle : "fadeUp"
	    });
	 
	    //Init progressBar where elem is $("#owl-demo")
	    function progressBar(elem){
	      $elem = elem;
	      //build progress bar elements
	      buildProgressBar();
	      //start counting
	      start();
	    }
	 
	    //create div#progressBar and div#bar then append to $(".owl-carousel")
	    function buildProgressBar(){
	      $progressBar = $("<div>",{
	        id:"progressBar"
	      });
	      $bar = $("<div>",{
	        id:"bar"
	      });
	      $progressBar.append($bar).appendTo($elem);
	    }
	 
	    function start() {
	      //reset timer
	      percentTime = 0;
	      isPause = false;
	      //run interval every 0.01 second
	      tick = setInterval(interval, 10);
	    };
	 
	    function interval() {
	      if(isPause === false){
	        percentTime += 1 / time;
	        $bar.css({
	           width: percentTime+"%"
	         });
	        //if percentTime is equal or greater than 100
	        if(percentTime >= 100){
	          //slide to next item 
	          $elem.trigger('owl.next')
	        }
	      }
	    }
	 
	    //pause while dragging 
	    function pauseOnDragging(){
	      isPause = true;
	    }
	 
	    //moved callback
	    function moved(){
	      //clear interval
	      clearTimeout(tick);
	      //start again
	      start();
	    }
	});

	//Initiat WOW JS
	new WOW().init();
	//smoothScroll
	smoothScroll.init();

	// portfolio filter
	$(window).load(function(){'use strict';
		var $portfolio_selectors = $('.portfolio-filter >li>a');
		var $portfolio = $('.portfolio-items');
		$portfolio.isotope({
			itemSelector : '.portfolio-item',
			layoutMode : 'fitRows'
		});
		
		$portfolio_selectors.on('click', function(){
			$portfolio_selectors.removeClass('active');
			$(this).addClass('active');
			var selector = $(this).attr('data-filter');
			$portfolio.isotope({ filter: selector });
			return false;
		});
	});



	// Contact form
	var form = $('#main-contact-form');
	form.submit(function(event){
		event.preventDefault();
		var form_status = $('<div class="form_status"></div>');
		$.ajax({
			url: $(this).attr('action'),
			beforeSend: function(){
				form.prepend( form_status.html('<p><i class="fa fa-spinner fa-spin"></i> Email is sending...</p>').fadeIn() );
			}
		}).done(function(data){
			form_status.html('<p class="text-success">Thank you for contacting us. As early as possible  we will contact you</p>').delay(3000).fadeOut();
		});
	});

	//Pretty Photo
	$("a[rel^='prettyPhoto']").prettyPhoto({
		social_tools: false
	});



});


var width = 400,
  height = 400,
  radius = 200,
  colors = d3.scale.category20();

var piedata = [
  {
    label: "Team",
    value: 800
  },
  {
    label: "Advisors & Partners",
    value: 100
  },
  {
    label: "Reward Pool",
    value: 100
  },
  {
    label: "Pre Sales",
    value: 600
  },
  {
    label: "Public Sales",
    value: 400
  }];

var piedata2 = [
  {
    label: "Technology Development",
    value: 4050
  },
  {
    label: "Marketing & Related",
    value: 600
  },
  {
    label: "Exchange Fees",
    value: 600
  },
  {
    label: "Data Feeds",
    value: 200
  },
  {
    label: "Operational",
    value: 150
  },
    {
    label: "Legal & Audit",
    value: 150
  },
  {
    label: "Reserve",
    value: 300
  }];

var pie = d3.layout.pie().value(function(d) {
  return d.value;
});

var arc = d3.svg.arc().outerRadius(radius);

var myChard = d3
  .select(".chart")
  .append("svg")
  .attr("width", width)
  .attr("height", height)
  .append("g")
  .attr(
    "transform",
    "translate(" + (width - radius) + ", " + (height - radius) + ")"
  )
  .selectAll("path")
  .data(pie(piedata))
  .enter()
  .append("g")
	.attr("class", "slice");
	
var myChard2 = d3
  .select(".chart2")
  .append("svg")
  .attr("width", width)
  .attr("height", height)
  .append("g")
  .attr(
    "transform",
    "translate(" + (width - radius) + ", " + (height - radius) + ")"
  )
  .selectAll("path")
  .data(pie(piedata2))
  .enter()
  .append("g")
  .attr("class", "slice");

var slices = d3
  .selectAll("g.slice")
  .append("path")
  .attr("fill", function(d, i) {
    return colors(i);
  })
  .attr("d", arc)
  .on("mouseover", function() {
    d3.select(this).style("opacity", 0.8);
  })
  .on("mouseout", function() {
    d3.select(this).style("opacity", 1);
  });

var text = d3
  .selectAll("g.slice")
  .append("text")
  .text(function(d) {
    return d.data.label;
  }) //slice = d, so we the slice's data.
  .attr("text-anchor", "middle")
  .attr("fill", "white")
  .attr("transform", function(d) {
    d.innerRadius = 0;
    d.outerRadius = radius;
    return "translate(" + arc.centroid(d) + ")"; //puts text at center of slice
  });



force.start();